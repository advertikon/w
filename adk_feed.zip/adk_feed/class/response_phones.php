<?php

require_once( __DIR__ . '/response.php' );

class ResponsePhones extends Response {
	
}