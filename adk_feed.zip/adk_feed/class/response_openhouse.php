<?php

require_once( __DIR__ . '/response.php' );

/**
 * Class ResponseOpenHouse
 * @property ResponseEvent Event
 */
class ResponseOpenHouse extends Response {
	
}