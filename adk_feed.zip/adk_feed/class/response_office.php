<?php

require_once( __DIR__ . '/response.php' );

class ResponseOffice extends Response {
	
}