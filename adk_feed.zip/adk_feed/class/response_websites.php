<?php

require_once( __DIR__ . '/response.php' );

class ResponseWebsites extends Response {
	
}