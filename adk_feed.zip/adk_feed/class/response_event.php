<?php

require_once( __DIR__ . '/response.php' );

/**
 * Class ResponseEvent
 * @property string StartDateTime
 * @property string EndDateTime
 * @property string Comments
 */
class ResponseEvent extends Response {
	
}