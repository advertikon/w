<?php

require_once( __DIR__ . '/response.php' );

/**
 * Class ResponsePropertyPhoto
 * @property string PhotoLastUpdated
 * @property string SequenceId
 * @property string Description
 */
class ResponsePropertyPhoto extends Response {
	
}