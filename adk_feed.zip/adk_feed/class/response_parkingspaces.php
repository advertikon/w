<?php

require_once( __DIR__ . '/response.php' );

class ResponseParkingSpaces extends Response {
	
}